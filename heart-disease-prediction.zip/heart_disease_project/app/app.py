"""
APPLICATION STREAMLIT — PREDICTION DE MALADIE CARDIAQUE
"""

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import plotly.express as px
import joblib
import json
import os
import warnings

warnings.filterwarnings("ignore")

# Configuration de la page
st.set_page_config(
    page_title="Prediction Maladie Cardiaque",
    page_icon=None,
    layout="wide",
    initial_sidebar_state="expanded",
)

# CSS personnalise
st.markdown("""
<style>
    .main-header {
        font-size: 2.4rem;
        font-weight: 800;
        color: #c0392b;
        text-align: center;
        padding: 10px 0 5px 0;
    }
    .sub-header {
        font-size: 1.1rem;
        color: #555;
        text-align: center;
        margin-bottom: 20px;
    }
    .metric-card {
        background: linear-gradient(135deg, #fff5f5, #ffe0e0);
        border-left: 5px solid #c0392b;
        border-radius: 10px;
        padding: 16px 20px;
        margin: 8px 0;
    }
    .success-card {
        background: linear-gradient(135deg, #f0fff4, #c6f6d5);
        border-left: 5px solid #27ae60;
        border-radius: 10px;
        padding: 20px;
        text-align: center;
        font-size: 1.3rem;
        font-weight: bold;
        color: #145a32;
    }
    .danger-card {
        background: linear-gradient(135deg, #fff5f5, #ffd5d5);
        border-left: 5px solid #c0392b;
        border-radius: 10px;
        padding: 20px;
        text-align: center;
        font-size: 1.3rem;
        font-weight: bold;
        color: #7b241c;
    }
    .info-box {
        background: #eaf4fb;
        border-radius: 8px;
        padding: 12px 16px;
        color: #1a5276;
        font-size: 0.95rem;
    }
    .stSlider > div > div > div > div { background-color: #c0392b; }
</style>
""", unsafe_allow_html=True)

# Chargement du modele
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

@st.cache_resource
def load_model():
    model_path = os.path.join(BASE_DIR, "models", "best_model.pkl")
    return joblib.load(model_path)

@st.cache_data
def load_data():
    data_path = os.path.join(BASE_DIR, "data", "heart.csv")
    return pd.read_csv(data_path)

model = load_model()
df = load_data()

# SIDEBAR
with st.sidebar:
    st.markdown("## Navigation")
    page = st.radio("", [
        "Accueil et Prediction",
        "Analyse des donnees",
        "Performance du modele",
        "A propos"
    ])
    st.markdown("---")
    st.markdown("### A propos du projet")
    st.markdown("""
    **Dataset :** Cleveland Heart Disease (UCI simule)

    **Modeles testes :**
    - Logistic Regression
    - Random Forest
    - Gradient Boosting
    - SVM
    - XGBoost

    **Meilleur AUC :** 0.79
    """)
    st.markdown("---")
    st.caption("Projet Data Science | 2025")

# ================================================================
# PAGE 1 — ACCUEIL ET PREDICTION
# ================================================================
if page == "Accueil et Prediction":
    st.markdown('<div class="main-header">Prediction de Maladie Cardiaque</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">Renseignez les parametres cliniques du patient pour obtenir une prediction</div>', unsafe_allow_html=True)
    st.markdown("---")

    col_form, col_result = st.columns([1.2, 1], gap="large")

    with col_form:
        st.markdown("### Informations du patient")

        col1, col2 = st.columns(2)
        with col1:
            age = st.slider("Age", 20, 80, 55)
            sex = st.selectbox("Sexe", [("Homme", 1), ("Femme", 0)], format_func=lambda x: x[0])[1]
            cp = st.selectbox("Type de douleur thoracique", [
                ("0 - Angine typique", 0),
                ("1 - Angine atypique", 1),
                ("2 - Douleur non-angineuse", 2),
                ("3 - Asymptomatique", 3)
            ], format_func=lambda x: x[0])[1]
            trestbps = st.slider("Pression arterielle au repos (mmHg)", 90, 200, 130)
            chol = st.slider("Cholesterol serique (mg/dl)", 100, 600, 250)
            fbs = st.selectbox("Glycemie a jeun > 120 mg/dl", [("Non", 0), ("Oui", 1)], format_func=lambda x: x[0])[1]

        with col2:
            restecg = st.selectbox("Resultats ECG au repos", [
                ("0 - Normal", 0),
                ("1 - Anomalie ST-T", 1),
                ("2 - Hypertrophie VG", 2)
            ], format_func=lambda x: x[0])[1]
            thalach = st.slider("Frequence cardiaque max", 70, 210, 150)
            exang = st.selectbox("Angine induite par l'exercice", [("Non", 0), ("Oui", 1)], format_func=lambda x: x[0])[1]
            oldpeak = st.slider("Depression ST (oldpeak)", 0.0, 6.5, 1.5, step=0.1)
            slope = st.selectbox("Pente du segment ST", [
                ("0 - Ascendante", 0),
                ("1 - Plate", 1),
                ("2 - Descendante", 2)
            ], format_func=lambda x: x[0])[1]
            ca = st.selectbox("Vaisseaux colores (fluoroscopie)", [0, 1, 2, 3, 4])
            thal = st.selectbox("Thalassemie", [
                ("0 - Normal", 0),
                ("1 - Defaut fixe", 1),
                ("2 - Normal (type 2)", 2),
                ("3 - Defaut reversible", 3)
            ], format_func=lambda x: x[0])[1]

        predict_btn = st.button("Lancer la prediction", use_container_width=True, type="primary")

    with col_result:
        st.markdown("### Resultat de la prediction")

        if predict_btn:
            patient = pd.DataFrame([{
                "age": age, "sex": sex, "cp": cp, "trestbps": trestbps,
                "chol": chol, "fbs": fbs, "restecg": restecg, "thalach": thalach,
                "exang": exang, "oldpeak": oldpeak, "slope": slope, "ca": ca, "thal": thal
            }])

            proba = model.predict_proba(patient)[0][1]
            pred = model.predict(patient)[0]

            # Jauge
            fig_gauge = go.Figure(go.Indicator(
                mode="gauge+number+delta",
                value=proba * 100,
                number={"suffix": "%", "font": {"size": 36}},
                title={"text": "Probabilite de maladie cardiaque", "font": {"size": 16}},
                gauge={
                    "axis": {"range": [0, 100], "tickwidth": 1},
                    "bar": {"color": "#c0392b" if proba > 0.5 else "#27ae60", "thickness": 0.3},
                    "steps": [
                        {"range": [0, 30], "color": "#d5f5e3"},
                        {"range": [30, 60], "color": "#fdebd0"},
                        {"range": [60, 100], "color": "#fadbd8"},
                    ],
                    "threshold": {
                        "line": {"color": "black", "width": 3},
                        "thickness": 0.75,
                        "value": 50
                    }
                }
            ))
            fig_gauge.update_layout(height=280, margin=dict(t=50, b=10, l=20, r=20))
            st.plotly_chart(fig_gauge, use_container_width=True)

            # Diagnostic
            if pred == 1:
                st.markdown(f"""
                <div class="danger-card">
                    MALADIE CARDIAQUE DETECTEE<br>
                    <span style="font-size:1rem">Probabilite : {proba*100:.1f}%</span>
                </div>""", unsafe_allow_html=True)
                st.error("Recommandation : Consultation cardiologique urgente conseillee.")
            else:
                st.markdown(f"""
                <div class="success-card">
                    PAS DE MALADIE CARDIAQUE<br>
                    <span style="font-size:1rem">Probabilite : {proba*100:.1f}%</span>
                </div>""", unsafe_allow_html=True)
                st.success("Recommandation : Continuez un suivi medical regulier.")

            # Recapitulatif patient
            st.markdown("#### Recapitulatif du patient")
            recap_df = pd.DataFrame({
                "Parametre": ["Age", "Sexe", "Douleur thoracique", "Pression", "Cholesterol",
                              "Glycemie jeun", "ECG", "FC max", "Angine effort",
                              "Oldpeak", "Pente ST", "Vaisseaux", "Thal"],
                "Valeur": [age, "Homme" if sex==1 else "Femme", cp, trestbps, chol,
                           "Oui" if fbs==1 else "Non", restecg, thalach,
                           "Oui" if exang==1 else "Non", oldpeak, slope, ca, thal]
            })
            st.dataframe(recap_df, use_container_width=True, hide_index=True)

        else:
            st.info("Remplissez le formulaire a gauche puis cliquez sur **Lancer la prediction**")
            st.markdown("""
            <div class="info-box">
            <b>Comment utiliser cette application ?</b><br><br>
            1. Renseignez les informations cliniques du patient dans le formulaire<br>
            2. Cliquez sur <b>Lancer la prediction</b><br>
            3. Le modele analyse les parametres et retourne une probabilite<br>
            4. Un diagnostic est affiche avec des recommandations<br><br>
            <i>Cet outil est a des fins educatives uniquement.</i>
            </div>
            """, unsafe_allow_html=True)

# ================================================================
# PAGE 2 — ANALYSE DES DONNEES
# ================================================================
elif page == "Analyse des donnees":
    st.markdown("## Analyse Exploratoire des Donnees")

    tab1, tab2, tab3 = st.tabs(["Dataset", "Distributions", "Correlations"])

    with tab1:
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Patients", f"{len(df):,}")
        col2.metric("Variables", str(df.shape[1]))
        col3.metric("Sains", f"{(df.target==0).sum()}")
        col4.metric("Malades", f"{(df.target==1).sum()}")

        st.markdown("#### Apercu du dataset")
        st.dataframe(df.head(15), use_container_width=True)

        st.markdown("#### Statistiques descriptives")
        st.dataframe(df.describe().round(2), use_container_width=True)

    with tab2:
        col_sel = st.selectbox("Choisir une variable", df.columns.tolist())
        fig = px.histogram(df, x=col_sel, color="target",
                           barmode="overlay", nbins=30,
                           color_discrete_map={0: "#4C72B0", 1: "#DD8452"},
                           labels={"target": "Classe", col_sel: col_sel},
                           title=f"Distribution de {col_sel} par classe")
        fig.update_layout(bargap=0.1)
        st.plotly_chart(fig, use_container_width=True)

        fig2 = px.box(df, x="target", y=col_sel, color="target",
                      color_discrete_map={0: "#4C72B0", 1: "#DD8452"},
                      labels={"target": "Classe (0=Sain, 1=Maladie)"},
                      title=f"Boxplot de {col_sel} par classe")
        st.plotly_chart(fig2, use_container_width=True)

    with tab3:
        corr = df.corr()
        fig_corr = px.imshow(corr, text_auto=".2f", aspect="auto",
                             color_continuous_scale="RdBu_r", zmin=-1, zmax=1,
                             title="Matrice de Correlation")
        fig_corr.update_layout(height=600)
        st.plotly_chart(fig_corr, use_container_width=True)

        st.markdown("#### Correlation avec la cible (target)")
        corr_target = df.corr()["target"].drop("target").sort_values(key=abs, ascending=False)
        fig_bar = px.bar(corr_target, orientation="v",
                         color=corr_target,
                         color_continuous_scale="RdBu_r",
                         title="Correlation de chaque variable avec la cible")
        st.plotly_chart(fig_bar, use_container_width=True)

# ================================================================
# PAGE 3 — PERFORMANCE DU MODELE
# ================================================================
elif page == "Performance du modele":
    st.markdown("## Performance du Modele")

    metrics = {
        "Logistic Regression":  {"AUC": 0.7883, "Accuracy": 0.8100, "F1": 0.4242, "Recall": 0.3043, "Precision": 0.7000},
        "Random Forest":        {"AUC": 0.7398, "Accuracy": 0.8050, "F1": 0.3607, "Recall": 0.2391, "Precision": 0.7333},
        "Gradient Boosting":    {"AUC": 0.7386, "Accuracy": 0.7950, "F1": 0.4675, "Recall": 0.3913, "Precision": 0.5806},
        "SVM":                  {"AUC": 0.7534, "Accuracy": 0.7850, "F1": 0.2456, "Recall": 0.1522, "Precision": 0.6364},
        "XGBoost":              {"AUC": 0.7463, "Accuracy": 0.7750, "F1": 0.4156, "Recall": 0.3478, "Precision": 0.5161},
        "XGBoost (Tuned)":      {"AUC": 0.7427, "Accuracy": 0.7800, "F1": 0.2143, "Recall": 0.1304, "Precision": 0.6000},
    }

    met_df = pd.DataFrame(metrics).T.reset_index().rename(columns={"index": "Modele"})

    col1, col2, col3 = st.columns(3)
    col1.metric("Meilleur AUC", "0.7883", "Logistic Regression")
    col2.metric("Meilleure Accuracy", "81.0%", "Logistic Regression")
    col3.metric("Meilleur F1", "0.4675", "Gradient Boosting")

    st.markdown("#### Tableau comparatif")
    st.dataframe(met_df.style.highlight_max(subset=["AUC","Accuracy","F1","Recall","Precision"],
                                             color="#d5f5e3"), use_container_width=True)

    st.markdown("#### Comparaison visuelle des metriques")
    metric_sel = st.multiselect("Choisir les metriques", ["AUC","Accuracy","F1","Recall","Precision"],
                                default=["AUC","Accuracy","F1"])

    fig_comp = px.bar(met_df, x="Modele", y=metric_sel, barmode="group",
                      title="Comparaison des modeles", height=450,
                      color_discrete_sequence=px.colors.qualitative.Set2)
    fig_comp.update_layout(xaxis_tickangle=-25)
    st.plotly_chart(fig_comp, use_container_width=True)

    st.markdown("#### Importance des features (Random Forest)")
    feat_names = ["age","sex","cp","trestbps","chol","fbs","restecg",
                  "thalach","exang","oldpeak","slope","ca","thal"]
    importances = [0.078, 0.055, 0.065, 0.072, 0.080, 0.040, 0.048,
                   0.090, 0.085, 0.095, 0.065, 0.088, 0.139]
    fi_df = pd.DataFrame({"Feature": feat_names, "Importance": importances})
    fi_df = fi_df.sort_values("Importance", ascending=True)
    fig_fi = px.bar(fi_df, x="Importance", y="Feature", orientation="h",
                    title="Importance des variables", height=450,
                    color="Importance", color_continuous_scale="Reds")
    st.plotly_chart(fig_fi, use_container_width=True)

# ================================================================
# PAGE 4 — A PROPOS
# ================================================================
elif page == "A propos":
    st.markdown("## A propos du projet")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("""
        ### Objectif
        Ce projet vise a predire le risque de maladie cardiaque chez un patient
        a partir de 13 parametres cliniques mesurables, en utilisant des algorithmes
        de Machine Learning supervise.

        ### Dataset
        - **Source :** Cleveland Heart Disease Dataset (UCI ML Repository)
        - **Taille :** 1 000 patients simules
        - **Variables :** 13 features + 1 cible binaire
        - **Classe positive :** Maladie cardiaque (1)

        ### Variables cliniques
        | Variable | Description |
        |----------|------------|
        | age | Age du patient |
        | sex | Sexe (0=F, 1=H) |
        | cp | Type douleur thoracique (0-3) |
        | trestbps | Pression arterielle repos |
        | chol | Cholesterol serique |
        | fbs | Glycemie a jeun |
        | restecg | ECG au repos |
        | thalach | FC maximale |
        | exang | Angine a l'effort |
        | oldpeak | Depression ST |
        | slope | Pente segment ST |
        | ca | Vaisseaux colores |
        | thal | Thalassemie |
        """)

    with col2:
        st.markdown("""
        ### Pipeline ML

        ```
        Donnees brutes
            |
            v
        EDA (Analyse exploratoire)
            |
            v
        Preprocessing
           - StandardScaler
           - Train/Test Split (80/20)
           - Stratification
            |
            v
        Entrainement (5 modeles)
           - Logistic Regression
           - Random Forest
           - Gradient Boosting
           - SVM
           - XGBoost
            |
            v
        Cross-Validation (5-Fold)
            |
            v
        Hyperparameter Tuning (GridSearchCV)
            |
            v
        Evaluation (AUC, F1, Precision, Recall)
            |
            v
        Sauvegarde modele (.pkl)
        ```

        ### Metriques d'evaluation
        - **AUC-ROC** : capacite de discrimination
        - **F1-Score** : equilibre precision/rappel
        - **Recall** : taux de detection des malades
        - **Precision** : fiabilite des alertes positives

        ### Avertissement
        > Cet outil est developpe a des fins pedagogiques uniquement.
        > Il ne constitue en aucun cas un avis medical.
        > Consultez toujours un professionnel de sante.
        """)
