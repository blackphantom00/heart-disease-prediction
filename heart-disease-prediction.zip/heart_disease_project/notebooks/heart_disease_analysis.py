"""
PROJET DATA SCIENCE — PREDICTION DE MALADIE CARDIAQUE
Pipeline complet : EDA -> Preprocessing -> ML -> Evaluation
"""

# -----------------------------------------------------------------
# 1. IMPORTS
# -----------------------------------------------------------------
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import joblib
import os

warnings.filterwarnings("ignore")
sns.set_theme(style="whitegrid", palette="muted")
plt.rcParams.update({"figure.dpi": 130, "font.size": 11})

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.metrics import (
    classification_report, confusion_matrix, roc_auc_score,
    roc_curve, precision_recall_curve, average_precision_score,
    ConfusionMatrixDisplay
)
from xgboost import XGBClassifier

os.makedirs("heart_disease_project/images", exist_ok=True)
os.makedirs("heart_disease_project/models", exist_ok=True)

# -----------------------------------------------------------------
# 2. CHARGEMENT ET DESCRIPTION DES DONNEES
# -----------------------------------------------------------------
print("\n" + "="*65)
print("  ETAPE 1 — CHARGEMENT DES DONNEES")
print("="*65)

df = pd.read_csv("heart_disease_project/data/heart.csv")

FEATURE_INFO = {
    "age":      "Age du patient (annees)",
    "sex":      "Sexe (1=Homme, 0=Femme)",
    "cp":       "Type de douleur thoracique (0-3)",
    "trestbps": "Pression arterielle au repos (mmHg)",
    "chol":     "Cholesterol serique (mg/dl)",
    "fbs":      "Glycemie a jeun > 120 mg/dl (1=oui)",
    "restecg":  "Resultats ECG au repos (0-2)",
    "thalach":  "Frequence cardiaque max atteinte",
    "exang":    "Angine induite par exercice (1=oui)",
    "oldpeak":  "Depression ST induite par l'exercice",
    "slope":    "Pente du segment ST (0-2)",
    "ca":       "Nombre de vaisseaux colores (0-4)",
    "thal":     "Thalassemie (0-3)",
    "target":   "Maladie cardiaque (1=oui, 0=non)",
}

print(f"\nDimensions : {df.shape[0]} patients x {df.shape[1]} variables")
print(f"\nDescription des variables :")
for col, desc in FEATURE_INFO.items():
    print(f"   - {col:<12} : {desc}")

print(f"\nApercu des donnees :")
print(df.head(8).to_string())

print(f"\nStatistiques descriptives :")
print(df.describe().round(2).to_string())

print(f"\nValeurs manquantes :")
print(df.isnull().sum())

print(f"\nDistribution de la cible :")
vc = df["target"].value_counts()
print(f"   Pas de maladie (0) : {vc[0]} ({vc[0]/len(df)*100:.1f}%)")
print(f"   Maladie        (1) : {vc[1]} ({vc[1]/len(df)*100:.1f}%)")

# -----------------------------------------------------------------
# 3. VISUALISATION EXPLORATOIRE (EDA)
# -----------------------------------------------------------------
print("\n" + "="*65)
print("  ETAPE 2 — ANALYSE EXPLORATOIRE (EDA)")
print("="*65)

COLORS = ["#4C72B0", "#DD8452"]

# Figure 1 : Distribution de la cible
fig, axes = plt.subplots(1, 2, figsize=(12, 4))
fig.suptitle("Distribution de la variable cible", fontsize=14, fontweight="bold")

vc.plot(kind="bar", ax=axes[0], color=COLORS, edgecolor="white", width=0.5)
axes[0].set_title("Effectifs")
axes[0].set_xticklabels(["Pas de maladie", "Maladie"], rotation=0)
axes[0].set_ylabel("Nombre de patients")
for i, v in enumerate(vc):
    axes[0].text(i, v + 5, str(v), ha="center", fontweight="bold")

axes[1].pie(vc, labels=["Pas de maladie", "Maladie"], autopct="%1.1f%%",
            colors=COLORS, startangle=90, wedgeprops=dict(edgecolor="white"))
axes[1].set_title("Proportions")
plt.tight_layout()
plt.savefig("heart_disease_project/images/01_target_distribution.png", bbox_inches="tight")
plt.close()
print("Figure 1 sauvegardee : Distribution de la cible")

# Figure 2 : Histogrammes des variables numeriques
num_cols = ["age", "trestbps", "chol", "thalach", "oldpeak"]
fig, axes = plt.subplots(1, 5, figsize=(18, 4))
fig.suptitle("Distribution des variables numeriques par classe", fontsize=13, fontweight="bold")

for ax, col in zip(axes, num_cols):
    for cls, color in zip([0, 1], COLORS):
        subset = df[df["target"] == cls][col]
        ax.hist(subset, bins=20, alpha=0.6, color=color, edgecolor="white",
                label="Maladie" if cls == 1 else "Sain")
    ax.set_title(col)
    ax.set_xlabel("")
    ax.legend(fontsize=8)

plt.tight_layout()
plt.savefig("heart_disease_project/images/02_numeric_distributions.png", bbox_inches="tight")
plt.close()
print("Figure 2 sauvegardee : Distributions numeriques")

# Figure 3 : Correlation heatmap
fig, ax = plt.subplots(figsize=(12, 9))
corr = df.corr()
mask = np.triu(np.ones_like(corr, dtype=bool))
sns.heatmap(corr, mask=mask, annot=True, fmt=".2f", cmap="coolwarm",
            center=0, ax=ax, linewidths=0.5, square=True,
            cbar_kws={"shrink": 0.8})
ax.set_title("Matrice de correlation", fontsize=14, fontweight="bold")
plt.tight_layout()
plt.savefig("heart_disease_project/images/03_correlation_heatmap.png", bbox_inches="tight")
plt.close()
print("Figure 3 sauvegardee : Heatmap de correlation")

# Figure 4 : Boxplots par classe
fig, axes = plt.subplots(2, 3, figsize=(16, 9))
fig.suptitle("Boxplots des variables numeriques par classe", fontsize=13, fontweight="bold")
axes = axes.flatten()

for i, col in enumerate(num_cols):
    df.boxplot(column=col, by="target", ax=axes[i],
               patch_artist=True,
               boxprops=dict(facecolor="#4C72B0", alpha=0.5),
               medianprops=dict(color="red", linewidth=2))
    axes[i].set_title(col)
    axes[i].set_xlabel("Classe (0=Sain, 1=Maladie)")

axes[-1].axis("off")
plt.suptitle("")
fig.suptitle("Boxplots des variables numeriques par classe", fontsize=13, fontweight="bold")
plt.tight_layout()
plt.savefig("heart_disease_project/images/04_boxplots.png", bbox_inches="tight")
plt.close()
print("Figure 4 sauvegardee : Boxplots")

# Figure 5 : Variables categorielles vs Target
cat_cols = ["sex", "cp", "fbs", "restecg", "exang", "slope"]
fig, axes = plt.subplots(2, 3, figsize=(16, 10))
fig.suptitle("Variables categorielles vs Target", fontsize=13, fontweight="bold")
axes = axes.flatten()

for i, col in enumerate(cat_cols):
    ct = df.groupby([col, "target"]).size().unstack(fill_value=0)
    ct.plot(kind="bar", ax=axes[i], color=COLORS, edgecolor="white")
    axes[i].set_title(col)
    axes[i].set_xlabel("")
    axes[i].legend(["Sain", "Maladie"], fontsize=8)
    axes[i].tick_params(axis="x", rotation=0)

plt.tight_layout()
plt.savefig("heart_disease_project/images/05_categorical_vs_target.png", bbox_inches="tight")
plt.close()
print("Figure 5 sauvegardee : Variables categorielles")

# -----------------------------------------------------------------
# 4. PREPROCESSING
# -----------------------------------------------------------------
print("\n" + "="*65)
print("  ETAPE 3 — PREPROCESSING")
print("="*65)

X = df.drop("target", axis=1)
y = df["target"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print(f"\nSplit Train/Test :")
print(f"   Train : {X_train.shape[0]} echantillons ({X_train.shape[0]/len(df)*100:.0f}%)")
print(f"   Test  : {X_test.shape[0]} echantillons  ({X_test.shape[0]/len(df)*100:.0f}%)")
print(f"\nStratification verifiee :")
print(f"   Train — Sain: {(y_train==0).sum()}, Maladie: {(y_train==1).sum()}")
print(f"   Test  — Sain: {(y_test==0).sum()},  Maladie: {(y_test==1).sum()}")

# -----------------------------------------------------------------
# 5. MODELISATION MULTI-MODELES
# -----------------------------------------------------------------
print("\n" + "="*65)
print("  ETAPE 4 — MODELISATION (5 MODELES)")
print("="*65)

models = {
    "Logistic Regression": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", LogisticRegression(max_iter=1000, random_state=42))
    ]),
    "Random Forest": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", RandomForestClassifier(n_estimators=200, random_state=42))
    ]),
    "Gradient Boosting": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", GradientBoostingClassifier(n_estimators=200, random_state=42))
    ]),
    "SVM": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", SVC(probability=True, random_state=42))
    ]),
    "XGBoost": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", XGBClassifier(n_estimators=200, random_state=42,
                              eval_metric="logloss", verbosity=0))
    ]),
}

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
results = {}

print("\nValidation croisee 5-Fold :\n")
for name, pipeline in models.items():
    scores = cross_val_score(pipeline, X_train, y_train, cv=cv,
                             scoring="roc_auc", n_jobs=-1)
    results[name] = {"cv_auc_mean": scores.mean(), "cv_auc_std": scores.std()}
    print(f"   {name:<25} -> AUC: {scores.mean():.4f} +/- {scores.std():.4f}")

# -----------------------------------------------------------------
# 6. TUNING DU MEILLEUR MODELE (XGBoost)
# -----------------------------------------------------------------
print("\n" + "="*65)
print("  ETAPE 5 — HYPERPARAMETER TUNING (XGBoost)")
print("="*65)

param_grid = {
    "clf__n_estimators": [100, 200, 300],
    "clf__max_depth": [3, 5, 7],
    "clf__learning_rate": [0.01, 0.05, 0.1],
    "clf__subsample": [0.8, 1.0],
}

xgb_pipeline = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", XGBClassifier(random_state=42, eval_metric="logloss", verbosity=0))
])

grid_search = GridSearchCV(
    xgb_pipeline, param_grid, cv=cv,
    scoring="roc_auc", n_jobs=-1, verbose=0
)
grid_search.fit(X_train, y_train)
best_model = grid_search.best_estimator_

print(f"\nMeilleurs parametres trouves :")
for k, v in grid_search.best_params_.items():
    print(f"   {k} = {v}")
print(f"\nMeilleur AUC CV : {grid_search.best_score_:.4f}")

# -----------------------------------------------------------------
# 7. EVALUATION SUR LE JEU DE TEST
# -----------------------------------------------------------------
print("\n" + "="*65)
print("  ETAPE 6 — EVALUATION SUR LE JEU DE TEST")
print("="*65)

trained_models = {}
test_results = {}

for name, pipeline in models.items():
    pipeline.fit(X_train, y_train)
    y_pred = pipeline.predict(X_test)
    y_prob = pipeline.predict_proba(X_test)[:, 1]
    auc = roc_auc_score(y_test, y_prob)
    report = classification_report(y_test, y_pred, output_dict=True)
    trained_models[name] = pipeline
    test_results[name] = {
        "auc": auc,
        "accuracy": report["accuracy"],
        "precision": report["1"]["precision"],
        "recall": report["1"]["recall"],
        "f1": report["1"]["f1-score"],
        "y_prob": y_prob,
        "y_pred": y_pred,
    }

# Resultats du meilleur modele tune
best_model.fit(X_train, y_train)
y_pred_best = best_model.predict(X_test)
y_prob_best = best_model.predict_proba(X_test)[:, 1]
auc_best = roc_auc_score(y_test, y_prob_best)
report_best = classification_report(y_test, y_pred_best, output_dict=True)
test_results["XGBoost (Tuned)"] = {
    "auc": auc_best,
    "accuracy": report_best["accuracy"],
    "precision": report_best["1"]["precision"],
    "recall": report_best["1"]["recall"],
    "f1": report_best["1"]["f1-score"],
    "y_prob": y_prob_best,
    "y_pred": y_pred_best,
}
trained_models["XGBoost (Tuned)"] = best_model

print("\nTableau comparatif (Test Set) :")
print(f"\n{'Modele':<28} {'AUC':>7} {'Acc':>7} {'Prec':>7} {'Recall':>7} {'F1':>7}")
print("-" * 65)
for name, r in test_results.items():
    print(f"{name:<28} {r['auc']:>7.4f} {r['accuracy']:>7.4f} "
          f"{r['precision']:>7.4f} {r['recall']:>7.4f} {r['f1']:>7.4f}")

best_name = max(test_results, key=lambda k: test_results[k]["auc"])
print(f"\nMeilleur modele global : {best_name} (AUC = {test_results[best_name]['auc']:.4f})")

print(f"\nRapport detaille — {best_name} :")
print(classification_report(y_test, test_results[best_name]["y_pred"],
                             target_names=["Sain", "Maladie"]))

# -----------------------------------------------------------------
# 8. VISUALISATIONS D'EVALUATION
# -----------------------------------------------------------------
print("\n" + "="*65)
print("  ETAPE 7 — VISUALISATIONS D'EVALUATION")
print("="*65)

palette = plt.cm.tab10.colors

# Figure 6 : Comparaison des metriques et courbes ROC
fig, axes = plt.subplots(1, 2, figsize=(16, 6))
fig.suptitle("Comparaison des modeles", fontsize=14, fontweight="bold")

metrics_list = ["auc", "accuracy", "f1"]
metric_labels = ["AUC-ROC", "Accuracy", "F1-Score"]
model_names = list(test_results.keys())
x = np.arange(len(model_names))
width = 0.25

for j, (met, lab) in enumerate(zip(metrics_list, metric_labels)):
    vals = [test_results[n][met] for n in model_names]
    axes[0].bar(x + j*width, vals, width, label=lab, alpha=0.85)

axes[0].set_xticks(x + width)
axes[0].set_xticklabels(model_names, rotation=30, ha="right")
axes[0].set_ylim(0.5, 1.05)
axes[0].set_title("Metriques par modele")
axes[0].legend()
axes[0].set_ylabel("Score")

for i, (name, r) in enumerate(test_results.items()):
    fpr, tpr, _ = roc_curve(y_test, r["y_prob"])
    axes[1].plot(fpr, tpr, label=f"{name} (AUC={r['auc']:.3f})", color=palette[i])

axes[1].plot([0, 1], [0, 1], "k--", linewidth=1, label="Aleatoire")
axes[1].set_xlabel("Taux de faux positifs")
axes[1].set_ylabel("Taux de vrais positifs")
axes[1].set_title("Courbes ROC")
axes[1].legend(fontsize=7, loc="lower right")

plt.tight_layout()
plt.savefig("heart_disease_project/images/06_model_comparison.png", bbox_inches="tight")
plt.close()
print("Figure 6 sauvegardee : Comparaison des modeles")

# Figure 7 : Matrice de confusion du meilleur modele
fig, ax = plt.subplots(figsize=(6, 5))
cm = confusion_matrix(y_test, test_results[best_name]["y_pred"])
disp = ConfusionMatrixDisplay(cm, display_labels=["Sain", "Maladie"])
disp.plot(ax=ax, colorbar=False, cmap="Blues")
ax.set_title(f"Matrice de confusion — {best_name}", fontsize=13, fontweight="bold")
plt.tight_layout()
plt.savefig("heart_disease_project/images/07_confusion_matrix.png", bbox_inches="tight")
plt.close()
print("Figure 7 sauvegardee : Matrice de confusion")

# Figure 8 : Importance des features (Random Forest)
rf_model = trained_models["Random Forest"]
importances = rf_model.named_steps["clf"].feature_importances_
feat_names = X.columns.tolist()
feat_imp_df = pd.DataFrame({"Feature": feat_names, "Importance": importances})
feat_imp_df = feat_imp_df.sort_values("Importance", ascending=True)

fig, ax = plt.subplots(figsize=(9, 7))
bars = ax.barh(feat_imp_df["Feature"], feat_imp_df["Importance"],
               color=plt.cm.RdYlGn(feat_imp_df["Importance"] / feat_imp_df["Importance"].max()),
               edgecolor="white")
ax.set_xlabel("Importance (gain)")
ax.set_title("Importance des variables — Random Forest", fontsize=13, fontweight="bold")
for bar, val in zip(bars, feat_imp_df["Importance"]):
    ax.text(val + 0.002, bar.get_y() + bar.get_height()/2,
            f"{val:.3f}", va="center", fontsize=9)
plt.tight_layout()
plt.savefig("heart_disease_project/images/08_feature_importance.png", bbox_inches="tight")
plt.close()
print("Figure 8 sauvegardee : Importance des features")

# Figure 9 : Courbes Precision-Rappel
fig, ax = plt.subplots(figsize=(8, 6))
for i, (name, r) in enumerate(test_results.items()):
    prec, rec, _ = precision_recall_curve(y_test, r["y_prob"])
    ap = average_precision_score(y_test, r["y_prob"])
    ax.plot(rec, prec, label=f"{name} (AP={ap:.3f})", color=palette[i])

ax.axhline(y_test.mean(), color="k", linestyle="--", label="Baseline (aleatoire)", linewidth=1)
ax.set_xlabel("Recall")
ax.set_ylabel("Precision")
ax.set_title("Courbes Precision-Rappel", fontsize=13, fontweight="bold")
ax.legend(fontsize=7)
plt.tight_layout()
plt.savefig("heart_disease_project/images/09_precision_recall.png", bbox_inches="tight")
plt.close()
print("Figure 9 sauvegardee : Courbes Precision-Rappel")

# -----------------------------------------------------------------
# 9. SAUVEGARDE DU MODELE FINAL
# -----------------------------------------------------------------
print("\n" + "="*65)
print("  ETAPE 8 — SAUVEGARDE DU MODELE")
print("="*65)

joblib.dump(trained_models[best_name], "heart_disease_project/models/best_model.pkl")
joblib.dump(best_model, "heart_disease_project/models/xgb_tuned.pkl")

import json
with open("heart_disease_project/models/feature_names.json", "w") as f:
    json.dump(feat_names, f)

print(f"\nModele sauvegarde : heart_disease_project/models/best_model.pkl")
print(f"XGBoost tune     : heart_disease_project/models/xgb_tuned.pkl")

# -----------------------------------------------------------------
# 10. PREDICTION EXEMPLE
# -----------------------------------------------------------------
print("\n" + "="*65)
print("  ETAPE 9 — EXEMPLE DE PREDICTION")
print("="*65)

nouveau_patient = pd.DataFrame([{
    "age": 58, "sex": 1, "cp": 0, "trestbps": 140,
    "chol": 260, "fbs": 0, "restecg": 0, "thalach": 138,
    "exang": 1, "oldpeak": 2.4, "slope": 1, "ca": 1, "thal": 2
}])

proba = trained_models[best_name].predict_proba(nouveau_patient)[0][1]
pred = trained_models[best_name].predict(nouveau_patient)[0]

print(f"\nProfil patient : Homme, 58 ans, douleur thoracique, cholesterol eleve")
print(f"\nProbabilite de maladie cardiaque : {proba*100:.1f}%")
print(f"Diagnostic : {'MALADIE CARDIAQUE DETECTEE' if pred == 1 else 'PAS DE MALADIE DETECTEE'}")

print("\n" + "="*65)
print("  PIPELINE COMPLET TERMINE AVEC SUCCES !")
print("="*65)
print(f"\nImages generees dans : heart_disease_project/images/")
print(f"Modeles sauvegardes  : heart_disease_project/models/")
