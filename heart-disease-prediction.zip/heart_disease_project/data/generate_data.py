"""
Génération du dataset Heart Disease (Cleveland UCI simulé)
"""
import pandas as pd
import numpy as np

np.random.seed(42)
n = 1000

age = np.random.randint(29, 77, n)
sex = np.random.choice([0, 1], n, p=[0.32, 0.68])
cp = np.random.choice([0, 1, 2, 3], n, p=[0.47, 0.17, 0.28, 0.08])
trestbps = np.random.randint(94, 200, n)
chol = np.random.randint(126, 564, n)
fbs = np.random.choice([0, 1], n, p=[0.85, 0.15])
restecg = np.random.choice([0, 1, 2], n, p=[0.50, 0.48, 0.02])
thalach = np.random.randint(71, 202, n)
exang = np.random.choice([0, 1], n, p=[0.67, 0.33])
oldpeak = np.round(np.random.uniform(0, 6.2, n), 1)
slope = np.random.choice([0, 1, 2], n, p=[0.21, 0.47, 0.32])
ca = np.random.choice([0, 1, 2, 3, 4], n, p=[0.59, 0.22, 0.12, 0.06, 0.01])
thal = np.random.choice([0, 1, 2, 3], n, p=[0.01, 0.06, 0.72, 0.21])

# Target logistique réaliste
log_odds = (
    -6
    + 0.03 * age
    + 0.5 * sex
    - 0.6 * cp
    + 0.01 * trestbps
    + 0.002 * chol
    + 0.2 * fbs
    - 0.01 * thalach
    + 0.7 * exang
    + 0.4 * oldpeak
    - 0.3 * slope
    + 0.5 * ca
    + 0.4 * thal
)
prob = 1 / (1 + np.exp(-log_odds))
target = (np.random.uniform(0, 1, n) < prob).astype(int)

df = pd.DataFrame({
    "age": age, "sex": sex, "cp": cp, "trestbps": trestbps,
    "chol": chol, "fbs": fbs, "restecg": restecg, "thalach": thalach,
    "exang": exang, "oldpeak": oldpeak, "slope": slope, "ca": ca,
    "thal": thal, "target": target
})

df.to_csv("heart_disease_project/data/heart.csv", index=False)
print(f"Dataset créé : {df.shape[0]} lignes, {df.shape[1]} colonnes")
print(df["target"].value_counts())
